package com.mipresupuesto.personalbudget.application.usecase.implementation;

import com.mipresupuesto.personalbudget.application.usecase.entityassembler.EntityAssembler;
import com.mipresupuesto.personalbudget.domain.BudgetDomain;
import com.mipresupuesto.personalbudget.entities.BudgetEntity;

public class BudgetEntityAssembler implements EntityAssembler<BudgetEntity, BudgetDomain> {

	@Override
	public BudgetDomain assembleDomain(BudgetEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BudgetEntity assembleEntity(BudgetDomain domain) {
		// TODO Auto-generated method stub
		return null;
	}

}
