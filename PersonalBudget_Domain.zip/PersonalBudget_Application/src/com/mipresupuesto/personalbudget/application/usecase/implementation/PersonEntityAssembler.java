package com.mipresupuesto.personalbudget.application.usecase.implementation;

public class PersonEntityAssembler {

}
