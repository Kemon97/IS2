package com.mipresupuesto.personalbudget.application.usecase.implementation;

import com.mipresupuesto.personalbudget.application.usecase.entityassembler.EntityAssembler;
import com.mipresupuesto.personalbudget.domain.PersonDomain;
import com.mipresupuesto.personalbudget.entities.PersonEntity;

public class PersonEntityAssembler implements EntityAssembler<PersonEntity, PersonDomain> {

	@Override
	public PersonDomain assembleDomain(PersonEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonEntity assembleEntity(PersonDomain domain) {
		// TODO Auto-generated method stub
		return null;
	}

}
