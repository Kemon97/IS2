package com.mipresupuesto.personalbudget.application.usecase.entityassembler;

public class BudgetEntityAssembler {

}
