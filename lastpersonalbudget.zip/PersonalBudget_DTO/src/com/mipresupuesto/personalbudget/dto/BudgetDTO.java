package com.mipresupuesto.personalbudget.dto;

public final class BudgetDTO {
	
	private YearDTO year;
	private PersonDTO person;
	
	
	public YearDTO getYear() {
		return year;
	}
	public void setYear(YearDTO year) {
		this.year = year;
	}
	public PersonDTO getPerson() {
		return person;
	}
	public void setPerson(PersonDTO person) {
		this.person = person;
	}
	
	

}
