package com.mipresupuesto.personalbudget.application.usecase.implementation;

import com.mipresupuesto.personalbudget.application.usecase.entityassembler.EntityAssembler;
import com.mipresupuesto.personalbudget.domain.YearDomain;
import com.mipresupuesto.personalbudget.entities.YearEntity;

public class YearEntityAssembler implements EntityAssembler<YearEntity, YearDomain> {

	@Override
	public YearDomain assembleDomain(YearEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public YearEntity assembleEntity(YearDomain domain) {
		// TODO Auto-generated method stub
		return null;
	}

}
