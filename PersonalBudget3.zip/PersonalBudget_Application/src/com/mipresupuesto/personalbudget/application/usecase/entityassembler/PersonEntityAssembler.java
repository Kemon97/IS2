package com.mipresupuesto.personalbudget.application.usecase.entityassembler;

public class PersonEntityAssembler {

}
