package com.mipresupuesto.personalbudget.application.service.dtoassembler;

public class YearDTOAssembler {

}
